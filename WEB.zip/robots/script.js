document.querySelectorAll('.info-btn').forEach(button => {
    button.addEventListener('click', (event) => {
      const card = event.target.closest('.robot-card');
      const info = card.querySelector('.robot-info');
      info.style.display = (info.style.display === 'block') ? 'none' : 'block';
    });
  });
  